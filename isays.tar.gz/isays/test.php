<?php	
		$res=end(explode('.','www.isays.cn/afagwegewggagewgweg'));
if($res!='jpg'||$res!='jpeg'||$res!='bmp')
{
		echo 'eeee';
}
?>

