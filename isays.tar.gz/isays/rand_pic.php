<?php include('include/functions.php');
rand_pic();?>
