<!doctypehtml>
<html>
<head>
<?php include('editor_post.php');?>
<meta charset='utf-8' />
<title>
admin_page
</title>
</head>
<body>
<p>editor_catagory</p>
<?php show_list();?> 
<?php echo 'editor_post';?>
</body>
</html>
