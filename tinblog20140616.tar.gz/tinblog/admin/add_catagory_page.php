<html>
<head>	
<title>
admin
</title>
<meta charset='utf-8' >
</head>
<body>
<form method='get' action='add_catagory.php'>
CATAGORY_NAME:<input name='catagory_name'></input>
<input name='submit' type='submit'></input>
</form>
</body>
</html>
