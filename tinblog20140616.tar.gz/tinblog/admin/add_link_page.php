<html>
<head>	
<title>
admin
</title>
<meta charset='utf-8' >
</head>
<body>
<form method='get' action='add_link.php'>
NO:<input name='no'></input>
LINK_NAME:<input name='name'></input>
LINK:<input name='link'></input>
TITLE:<input name='title'></input>
<input name='submit' type='submit'></input>
</form>
</body>
</html>
