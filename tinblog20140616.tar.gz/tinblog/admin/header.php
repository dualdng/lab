<!doctypehtml>
<?php include('functions.php');
include('../include/mysql_con.php');
?>
<html>
<title>
admin
</title>
<head>
<meta charset='utf-8' >
<link rel='stylesheet' href='style.css' />
<link c
</head>
<body>
