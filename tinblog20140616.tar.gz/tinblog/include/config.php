<?php
define('url','127.0.0.1');
define('usrname','blog');
define('passwd','d3621201,');
define('database','blog');
?>
