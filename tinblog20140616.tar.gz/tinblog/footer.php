<footer>
<div id='footer'><span>Powered by <a href='#'>TInty</a></span></div>
</footer>
</body>
</html>
